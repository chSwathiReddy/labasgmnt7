package com.eventapp;

import java.time.LocalDate;
import java.time.Month;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.eventapp.entities.Event;
import com.eventapp.entities.User;
import com.eventapp.service.EventService;
import com.eventapp.service.UserService;
@Component
public class DataInit implements CommandLineRunner{
@Autowired
	private EventService eventService;
@Autowired
private UserService userService;
	@Override
	public void run(String... args) throws Exception {
		BCryptPasswordEncoder encoder=new BCryptPasswordEncoder();
		User user1=new User("swathi", encoder.encode("swa"), "ROLE_ADMIN");
		User user2=new User("preethi", encoder.encode("pre123"), "ROLE_CLERK");
		userService.addUser(user1);
		userService.addUser(user2);
		
		/*
		 * Event e1=new Event("bharthanatyam dhamaka","chennai", 500.00, 10, 20,
		 * LocalDate.of(2020, Month.DECEMBER, 31));
		 */ 
		  /* Event e2=new
		  Event("singing","hyderabad", 600.00, 15, 30, LocalDate.of(2021,
		 * Month.FEBRUARY, 22)); Event e3=new Event("drawing","chennai", 4500.00, 5,
		 * 300, LocalDate.of(2021, Month.FEBRUARY, 23)); Event e4=new
		 * Event("cooking","banglore", 5500.00, 10, 200, LocalDate.of(2021,
		 * Month.FEBRUARY, 20)); Event e5=new Event("java basics","delhi", 900.00, 20,
		 * 500, LocalDate.of(2021, Month.FEBRUARY, 24)); eventService.addEvent(e1);
		 * eventService.addEvent(e2); eventService.addEvent(e3);
		 * eventService.addEvent(e4); eventService.addEvent(e5);
		 */
		 // eventService.addEvent(e1);
	}

}
