package com.eventapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventmgtApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventmgtApplication.class, args);
	}

}
