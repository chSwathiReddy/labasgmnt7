package com.eventapp.dto;

public class TicketCancelRequest {
private int eventid;
private int noOfTicket;
public int getEventid() {
	return eventid;
}
public void setEventid(int eventid) {
	this.eventid = eventid;
}
public int getNoOfTicket() {
	return noOfTicket;
}
public void setNoOfTicket(int noOfTicket) {
	this.noOfTicket = noOfTicket;
}

}
