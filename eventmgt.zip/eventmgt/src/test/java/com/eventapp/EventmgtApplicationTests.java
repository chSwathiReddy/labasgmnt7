package com.eventapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventmgtApplicationTests {

	@Test
	void contextLoads() {
	}

}
